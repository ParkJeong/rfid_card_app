package com.gonghwachun.rfidcarappjava;

import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Handler;
import android.provider.BaseColumns;
import android.provider.Settings;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import com.jjoe64.graphview.series.DataPoint;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class RfidCardFunction extends AppCompatActivity {

    Toolbar tb;
    SharedPreferences setting;
    SharedPreferences.Editor editor;
    ImageButton imageButton;

    String val[];
    int index;
    Button button;
    String[] weightList = new String[1000];
    int weight;
    TextView textView1;
    Cursor iCursor;
    int count = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_rfid_card_function);

        tb =(Toolbar) findViewById(R.id.toolbar);
        imageButton = findViewById(R.id.imageButton);
        textView1 = findViewById(R.id.checkDisquantity);


        setting = getSharedPreferences("setting", 0);
        editor = setting.edit();


        setSupportActionBar(tb);
        getSupportActionBar().setTitle("RFID 카드 기능");

        button = findViewById(R.id.button2);
/*

        DbOpenHelper mDbOpenHelper = new DbOpenHelper(this);
        mDbOpenHelper.open();
        mDbOpenHelper.create();

        mDbOpenHelper.insertColumn(10);//2
        mDbOpenHelper.insertColumn(2);
        mDbOpenHelper.insertColumn(4);
        mDbOpenHelper.insertColumn(8);
        mDbOpenHelper.insertColumn(10);
        mDbOpenHelper.insertColumn(2);
        mDbOpenHelper.insertColumn(4);
        mDbOpenHelper.insertColumn(4);
        mDbOpenHelper.insertColumn(4);
        mDbOpenHelper.insertColumn(4);//11
        mDbOpenHelper.insertColumn(2);
        mDbOpenHelper.insertColumn(4);
        mDbOpenHelper.insertColumn(8);
        mDbOpenHelper.insertColumn(8);
        mDbOpenHelper.insertColumn(8);
        mDbOpenHelper.insertColumn(4);
        mDbOpenHelper.insertColumn(10);
        mDbOpenHelper.insertColumn(8);
        mDbOpenHelper.insertColumn(8);
        mDbOpenHelper.insertColumn(4);//21
        mDbOpenHelper.insertColumn(2);
        mDbOpenHelper.insertColumn(2);
        mDbOpenHelper.insertColumn(10);
        mDbOpenHelper.insertColumn(8);
        mDbOpenHelper.insertColumn(6);
        mDbOpenHelper.insertColumn(2);
        mDbOpenHelper.insertColumn(8);
        mDbOpenHelper.insertColumn(4);
        mDbOpenHelper.insertColumn(4);
        mDbOpenHelper.insertColumn(6);//31


*/

        button.setOnClickListener(new View.OnClickListener()
        {


            @Override
            public void onClick (View v)
            {
                Handler handler = new Handler();
                handler.postDelayed(new Runnable() {
                    public void run() {



                if (count == 0) {
                    count++;
                    textView1.setText("10kg을 버렸습니다.");
                }
                else if(count == 1)
                {
                    count++;
                    textView1.setText("2kg을 버렸습니다.");

                }
                else if(count == 2)
                {
                    count++;
                    textView1.setText("4kg을 버렸습니다.");

                }
                else if(count == 3)
                {
                    count++;
                    textView1.setText("8kg을 버렸습니다.");

                }
                else if(count == 4)
                {
                    count++;
                    textView1.setText("2kg을 버렸습니다.");

                }
                else if(count == 5)
                {
                    count++;
                    textView1.setText("2kg을 버렸습니다.");

                }
                else if(count == 6)
                {
                    count++;
                    textView1.setText("4kg을 버렸습니다.");

                }
                else if(count == 7)
                {
                    count++;
                    textView1.setText("4kg을 버렸습니다.");

                }
                else if(count == 8)
                {
                    count++;
                    textView1.setText("4kg을 버렸습니다.");

                }
                else if(count == 9)
                {
                    count++;
                    textView1.setText("4kg을 버렸습니다.");

                }
                else if(count == 10)
                {
                    count++;
                    textView1.setText("2kg을 버렸습니다.");

                }
                else if(count == 11)
                {
                    count++;
                    textView1.setText("4kg을 버렸습니다.");

                }
                else if(count == 12)
                {
                    count++;
                    textView1.setText("8kg을 버렸습니다.");

                }
                else if(count == 13)
                {
                    count++;
                    textView1.setText("8kg을 버렸습니다.");

                }
                else if(count == 14)
                {
                    count++;
                    textView1.setText("8kg을 버렸습니다.");

                }
                else if(count == 15)
                {
                    count++;
                    textView1.setText("4kg을 버렸습니다.");

                }
                else if(count == 16)
                {
                    count++;
                    textView1.setText("10kg을 버렸습니다.");

                }
                else if(count == 17)
                {
                    count++;
                    textView1.setText("8kg을 버렸습니다.");

                }
                else if(count == 18)
                {
                    count++;
                    textView1.setText("8kg을 버렸습니다.");

                }

                else if(count == 19)
                {
                    count++;
                    textView1.setText("4kg을 버렸습니다.");

                }
                else if(count == 20)
                {
                    count++;
                    textView1.setText("2kg을 버렸습니다.");

                }
                else if(count == 21)
                {
                    count++;
                    textView1.setText("2kg을 버렸습니다.");

                }
                    }
                }, 1700);
            }

        });


/*
        BufferedReader reader = null;
        try {

            reader = new BufferedReader(new InputStreamReader(getAssets().open("weight.csv")));
            reader.readLine();  //skip first line of file

            String mline;

            weights.clear();


            while ((mline = reader.readLine()) != null) {
                val = mline.split(",");
                weights.add(val[0]);
            }


        } catch (IOException e) {
            e.printStackTrace();
        }*/


        imageButton.setOnClickListener(new View.OnClickListener(){

            @Override
            public void onClick(View view){
                Intent intent = new Intent(Settings.ACTION_NFCSHARING_SETTINGS);
                startActivity(intent);


            }
        });



    }







    //추가된 소스, ToolBar에 menu.xml을 인플레이트함
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        //return super.onCreateOptionsMenu(menu);
        MenuInflater menuInflater = getMenuInflater();
        menuInflater.inflate(R.menu.main_menu, menu);
        return true;
    }

    //추가된 소스, ToolBar에 추가된 항목의 select 이벤트를 처리하는 함수
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        //return super.onOptionsItemSelected(item);

        Intent intent;
        switch (item.getItemId()) {
            case R.id.menu_rfid:
                intent = new Intent(getApplicationContext(), RfidCardFunction.class);
                startActivity(intent);
                return true;

            case R.id.menu_mywaste:
                intent = new Intent(getApplicationContext(), CheckMyWaste.class);
                startActivity(intent);
                return true;
/*
            case R.id.menu_aptwaste:
                intent = new Intent(getApplicationContext(), CompareWithAptWaste.class);
                startActivity(intent);
                return true;
*/
            case R.id.menu_nearbywaste:
                intent = new Intent(getApplicationContext(), CompareWithNeighborWaste.class);
                startActivity(intent);
                return true;

            case R.id.menu_logout:
                editor.clear();
                editor.commit();
                intent = new Intent(getApplicationContext(), MainActivity.class);
                startActivity(intent);
                return true;


        }
        return true;

    }

}
