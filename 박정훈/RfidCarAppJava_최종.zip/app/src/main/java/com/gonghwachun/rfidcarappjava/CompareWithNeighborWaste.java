package com.gonghwachun.rfidcarappjava;

import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.jjoe64.graphview.GraphView;
import com.jjoe64.graphview.series.DataPoint;
import com.jjoe64.graphview.series.LineGraphSeries;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;


public class CompareWithNeighborWaste extends AppCompatActivity {

    Toolbar tb;
    SharedPreferences setting;
    SharedPreferences.Editor editor;

    GraphView graph;
    GraphView graph2;

    String val[];
    String sidoName;
    String sggName;
    Double disQuantityAvg;
    Double time;

    int maxXVal;
    int maxYVal;
    int maxXVal2;
    int maxYVal2;

    Button button;

    EditText sidoText;
    EditText sggText;
    EditText startText;
    EditText endText;


    TextView textView;
    TextView textView8;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_compare_with_neighbor_waste);


        tb =(Toolbar) findViewById(R.id.toolbar);
        graph = findViewById(R.id.graph);
        graph2 = findViewById(R.id.graph2);

        button = findViewById(R.id.button);


        sidoText = findViewById(R.id.aptName);
        sggText = findViewById(R.id.sggName);
        startText = findViewById(R.id.startTime);
        endText = findViewById(R.id.endTime);
        setting = getSharedPreferences("setting", 0);
        editor = setting.edit();

        textView = findViewById(R.id.textView);
        textView8 = findViewById(R.id.textView8);





        graph.getViewport().setXAxisBoundsManual(true);
        graph.getViewport().setScrollable(true); // enables horizontal scrolling
        graph.getViewport().setScrollableY(true); // enables vertical scrolling

        graph2.getViewport().setXAxisBoundsManual(true);
        graph2.getViewport().setScrollable(true); // enables horizontal scrolling
        graph2.getViewport().setScrollableY(true); // enables vertical scrolling



        button.setOnClickListener(new View.OnClickListener()
        {
            LineGraphSeries<DataPoint>series = new LineGraphSeries<DataPoint>();
            LineGraphSeries<DataPoint>series2 = new LineGraphSeries<DataPoint>();


            @Override
            public void onClick (View v)
            {
                textView.setText("평균하루 배출량  (kg)");
                textView8.setText("평균하루 배출량  (kg)");


                maxXVal = 0;
                maxYVal = 0;
                maxXVal2 = 0;
                maxYVal2 = 0;
                graph.removeAllSeries();
                graph2.removeAllSeries();

                BufferedReader reader = null;
                try {

                    reader = new BufferedReader(new InputStreamReader(getAssets().open("mainCityDateDf.csv")));
                    reader.readLine();  //skip first line of file

                    String mline;


                    int k = 0;

                    String temp1 = "제주특별자치도";
                    String temp2 = "제주시";
                    while ((mline = reader.readLine()) != null) {
                        k = k+1;
                        if (k%31 == 30) {
                            val = mline.split(",");

                            sidoName = val[0];
                            sggName = val[1];


                            if (sggName.equals(sggText.getText().toString()) && sidoName.equals(sidoText.getText().toString())) {
                                time = Double.parseDouble(val[3]);
                                Double startTime = Double.parseDouble(startText.getText().toString());
                                Double endTime = Double.parseDouble(endText.getText().toString());

                                startTime = startTime * 100;
                                endTime = endTime * 100;

                                if (startTime <= time && time <= endTime) {
                                    disQuantityAvg = Double.parseDouble(val[2]);
                                    if (disQuantityAvg > maxYVal) {
                                        maxYVal = Integer.valueOf(disQuantityAvg.intValue()) + 1;
                                    }
                                    series.appendData(new DataPoint(maxXVal, (disQuantityAvg*26)/1000), true, 50000);
                                    maxXVal++;
                                } else {
                                }
                            } else {
                            }

                            if (sggName.equals(temp2) && sidoName.equals(temp1)) {
                                time = Double.parseDouble(val[3]);
                                Double startTime = Double.parseDouble(startText.getText().toString());
                                Double endTime = Double.parseDouble(endText.getText().toString());

                                startTime = startTime * 100;
                                endTime = endTime * 100;

                                if (startTime <= time && time <= endTime) {
                                    disQuantityAvg = Double.parseDouble(val[2]);
                                    if (disQuantityAvg > maxYVal2) {
                                        maxYVal2 = Integer.valueOf(disQuantityAvg.intValue()) + 1;
                                    }
                                    series2.appendData(new DataPoint(maxXVal2, (disQuantityAvg*26)/1000), true, 50000);
                                    maxXVal2++;
                                } else {
                                }
                            } else {
                            }



                        }
                    }


                } catch (IOException e) {
                    e.printStackTrace();
                }

                maxXVal = maxXVal -1;
                maxXVal2 = maxXVal2 -1;

                graph.getViewport().setMinX(0);
                graph.getViewport().setMaxX(maxXVal);
                graph.getViewport().setMinY(0);
                graph.getViewport().setMaxY(maxYVal);
                graph.addSeries(series);

                graph2.getViewport().setMinX(0);
                graph2.getViewport().setMaxX(maxXVal2);
                graph2.getViewport().setMinY(0);
                graph2.getViewport().setMaxY(maxYVal2);
                graph2.addSeries(series2);
            }

        });




        setSupportActionBar(tb);
        getSupportActionBar().setTitle("지자체 배출량 비교");





    }









    //추가된 소스, ToolBar에 menu.xml을 인플레이트함
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        //return super.onCreateOptionsMenu(menu);
        MenuInflater menuInflater = getMenuInflater();
        menuInflater.inflate(R.menu.main_menu, menu);
        return true;
    }

    //추가된 소스, ToolBar에 추가된 항목의 select 이벤트를 처리하는 함수
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        //return super.onOptionsItemSelected(item);

        Intent intent;
        switch (item.getItemId()) {
            case R.id.menu_rfid:
                intent = new Intent(getApplicationContext(), RfidCardFunction.class);
                startActivity(intent);
                return true;

            case R.id.menu_mywaste:
                intent = new Intent(getApplicationContext(), CheckMyWaste.class);
                startActivity(intent);
                return true;
/*
            case R.id.menu_aptwaste:
                intent = new Intent(getApplicationContext(), CompareWithAptWaste.class);
                startActivity(intent);
                return true;
*/
            case R.id.menu_nearbywaste:
                intent = new Intent(getApplicationContext(), CompareWithNeighborWaste.class);
                startActivity(intent);
                return true;

            case R.id.menu_logout:
                editor.clear();
                editor.commit();
                intent = new Intent(getApplicationContext(), MainActivity.class);
                startActivity(intent);
                finish();
                return true;


        }
        return true;

    }

}
