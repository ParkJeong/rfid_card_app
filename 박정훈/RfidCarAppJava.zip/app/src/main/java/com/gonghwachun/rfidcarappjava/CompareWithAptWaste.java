package com.gonghwachun.rfidcarappjava;

import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;

public class CompareWithAptWaste extends AppCompatActivity {

    Toolbar tb;
    SharedPreferences setting;
    SharedPreferences.Editor editor;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_compare_with_apt_waste);


        tb =(Toolbar) findViewById(R.id.toolbar);

        setting = getSharedPreferences("setting", 0);
        editor = setting.edit();

        setSupportActionBar(tb);
        getSupportActionBar().setTitle("아파트 배출량 비교");
    }



    //추가된 소스, ToolBar에 menu.xml을 인플레이트함
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        //return super.onCreateOptionsMenu(menu);
        MenuInflater menuInflater = getMenuInflater();
        menuInflater.inflate(R.menu.main_menu, menu);
        return true;
    }

    //추가된 소스, ToolBar에 추가된 항목의 select 이벤트를 처리하는 함수
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        //return super.onOptionsItemSelected(item);

        Intent intent;
        switch (item.getItemId()) {
            case R.id.menu_rfid:
                intent = new Intent(getApplicationContext(), RfidCardFunction.class);
                startActivity(intent);
                return true;

            case R.id.menu_mywaste:
                intent = new Intent(getApplicationContext(), CheckMyWaste.class);
                startActivity(intent);
                return true;

            case R.id.menu_aptwaste:
                intent = new Intent(getApplicationContext(), CompareWithAptWaste.class);
                startActivity(intent);
                return true;

            case R.id.menu_nearbywaste:
                intent = new Intent(getApplicationContext(), CompareWithNeighborWaste.class);
                startActivity(intent);
                return true;

            case R.id.menu_logout:
                editor.clear();
                editor.commit();
                intent = new Intent(getApplicationContext(), MainActivity.class);
                startActivity(intent);
                finish();
                return true;


        }
        return true;

    }

}
