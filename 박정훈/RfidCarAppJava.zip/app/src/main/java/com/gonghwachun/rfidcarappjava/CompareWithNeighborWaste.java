package com.gonghwachun.rfidcarappjava;

import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.TextView;

import com.github.mikephil.charting.charts.LineChart;
import com.github.mikephil.charting.data.LineDataSet;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;


public class CompareWithNeighborWaste extends AppCompatActivity {

    Toolbar tb;
    SharedPreferences setting;
    SharedPreferences.Editor editor;

    LineChart lineChart ;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_compare_with_neighbor_waste);


        tb =(Toolbar) findViewById(R.id.toolbar);


        setting = getSharedPreferences("setting", 0);
        editor = setting.edit();


        lineChart = (LineChart) findViewById(R.id.chart);




        setSupportActionBar(tb);
        getSupportActionBar().setTitle("지자체 배출량 비교");

        loadFromRawResource();


    }
    private void loadFromRawResource() {
        try {
            InputStream is = getResources().openRawResource(R.raw.maincitycodedf);
            BufferedReader buffer = new BufferedReader
                    (new InputStreamReader(is));

            String str = buffer.readLine(); // 파일에서 한줄을 읽어옴

            // 파일에서 읽은 데이터를 저장하기 위해서 만든 변수
            StringBuffer data = new StringBuffer();

            while (str != null) {
                data.append(str + "\n");
                str = buffer.readLine();
            }
            buffer.close();
           // temp.setText(data);
           // result.setText(data);
        } catch (Exception e) {
           // temp.setText("Exception: raw resouce file reading");
           // result.setText("Exception: raw resource file reading");
        }
    }


    //추가된 소스, ToolBar에 menu.xml을 인플레이트함
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        //return super.onCreateOptionsMenu(menu);
        MenuInflater menuInflater = getMenuInflater();
        menuInflater.inflate(R.menu.main_menu, menu);
        return true;
    }

    //추가된 소스, ToolBar에 추가된 항목의 select 이벤트를 처리하는 함수
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        //return super.onOptionsItemSelected(item);

        Intent intent;
        switch (item.getItemId()) {
            case R.id.menu_rfid:
                intent = new Intent(getApplicationContext(), RfidCardFunction.class);
                startActivity(intent);
                return true;

            case R.id.menu_mywaste:
                intent = new Intent(getApplicationContext(), CheckMyWaste.class);
                startActivity(intent);
                return true;

            case R.id.menu_aptwaste:
                intent = new Intent(getApplicationContext(), CompareWithAptWaste.class);
                startActivity(intent);
                return true;

            case R.id.menu_nearbywaste:
                intent = new Intent(getApplicationContext(), CompareWithNeighborWaste.class);
                startActivity(intent);
                return true;

            case R.id.menu_logout:
                editor.clear();
                editor.commit();
                intent = new Intent(getApplicationContext(), MainActivity.class);
                startActivity(intent);
                finish();
                return true;


        }
        return true;

    }

}
